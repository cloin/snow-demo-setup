Role Name
=========

This role calls the module upcase

Requirements
------------
None

Role Variables
--------------

test_name

Dependencies
------------


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      collections:
        - ansible.eda
      roles:
         - { role: test_role, test_name: 42 }

License
-------

BSD

Author Information
------------------


