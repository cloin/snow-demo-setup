
# EDA Event Transport

An event transport plugin connects to a source of events and handles the transport of events
from the source to EDA.  Examples of this are plugins that handle connecting to kafka topics,
and may run webhooks.


