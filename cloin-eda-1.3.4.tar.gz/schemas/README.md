
# Schemas Directory

A schema is a description of the structure and types of a data structure.

- event
