
# EDA Event Schemas

